/**
 * @author Direction
 */

alert('hello 我是引入的文件!');
